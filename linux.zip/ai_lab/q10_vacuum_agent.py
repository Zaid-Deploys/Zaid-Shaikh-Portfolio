import itertools

PERCEPTS = [(loc, st) for loc in "AB" for st in ("Clean", "Dirty")]

def rule(last):
    loc, status = last
    if status == "Dirty": return "Suck"
    return "Right" if loc == "A" else "Left"

def build_table(horizon=4):

    table = {}
    for n in range(1, horizon + 1):
        for seq in itertools.product(PERCEPTS, repeat=n):
            table[seq] = rule(seq[-1])
    return table

class TableDrivenAgent:
    def __init__(self, table):
        self.table, self.percepts = table, []
    def act(self, percept):
        self.percepts.append(percept)
        return self.table.get(tuple(self.percepts), "NoOp")

class VacuumEnvironment:
    def __init__(self, a="Dirty", b="Dirty", loc="A"):
        self.status, self.loc, self.score = {"A": a, "B": b}, loc, 0
    def percept(self):
        return (self.loc, self.status[self.loc])
    def execute(self, action):
        if action == "Suck":   self.status[self.loc] = "Clean"
        elif action == "Right": self.loc = "B"
        elif action == "Left":  self.loc = "A"
        self.score += sum(s == "Clean" for s in self.status.values())
        if action in ("Left", "Right", "Suck"): self.score -= 0.5

def run(a, b, loc, steps=6):
    table = build_table(4)
    env, agent = VacuumEnvironment(a, b, loc), TableDrivenAgent(table)
    print(f"\nStart: A={a}, B={b}, agent at {loc}  (table size = {len(table)} entries)")
    for t in range(1, steps + 1):
        p = env.percept(); act = agent.act(p); env.execute(act)
        print(f" t={t}: percept={p!s:20s} action={act:6s} -> A={env.status['A']}, "
              f"B={env.status['B']}, at {env.loc}, score={env.score}")

if __name__ == "__main__":
    print("PEAS")
    print("  Performance : +1 per clean square per time step, small penalty per action")
    print("  Environment : two squares A and B, each Clean or Dirty")
    print("  Actuators   : Left, Right, Suck, NoOp")
    print("  Sensors     : location sensor, dirt sensor -> percept = (location, status)")
    print("\nEnvironment classification")
    print("  Observable    : partially (senses only the current square)")
    print("  Agents        : single agent")
    print("  Deterministic : yes")
    print("  Episodic      : no (sequential)")
    print("  Static        : yes")
    print("  Discrete      : yes")
    print("  Known         : yes")
    run("Dirty", "Dirty", "A")
    run("Clean", "Dirty", "B")
    run("Clean", "Clean", "A")
    print("\nNote: the table grows as 4^t entries, so table-driven agents don't scale;"
          " a simple reflex agent needs only 4 rules.")
