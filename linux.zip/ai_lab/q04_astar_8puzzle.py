import heapq, itertools

GOAL = (1, 2, 3, 4, 5, 6, 7, 8, 0)
START = (8, 1, 3, 4, 0, 2, 7, 6, 5)

def neighbors(state):

    z = state.index(0)
    r, c = divmod(z, 3)
    options = []
    if r > 0: options.append(("Up", z - 3))
    if r < 2: options.append(("Down", z + 3))
    if c > 0: options.append(("Left", z - 1))
    if c < 2: options.append(("Right", z + 1))
    for name, t in options:
        s = list(state)
        s[z], s[t] = s[t], s[z]
        yield name, tuple(s)

def manhattan(state, goal=GOAL):
    pos = {v: divmod(i, 3) for i, v in enumerate(goal)}
    total = 0
    for i, v in enumerate(state):
        if v != 0:
            r, c = divmod(i, 3)
            gr, gc = pos[v]
            total += abs(r - gr) + abs(c - gc)
    return total

def is_solvable(state):
    tiles = [x for x in state if x != 0]
    inv = sum(1 for i in range(len(tiles)) for j in range(i + 1, len(tiles))
              if tiles[i] > tiles[j])
    return inv % 2 == 0

def board(state):
    return "\n".join(" ".join(str(x) if x else "_" for x in state[i:i + 3])
                     for i in (0, 3, 6))

def print_solution(parents, goal, algo):

    path, s = [], goal
    while parents[s] is not None:
        prev, move = parents[s]
        path.append((move, s))
        s = prev
    path.reverse()
    print(f"\n{algo}: solution found in {len(path)} moves")
    print("Moves:", " ".join(m for m, _ in path))
    print("\nStep 0 (start)")
    print(board(s))
    for i, (m, st) in enumerate(path, 1):
        print(f"\nStep {i}: blank moves {m}")
        print(board(st))

def astar(start, goal=GOAL):
    tie = itertools.count()
    frontier = [(manhattan(start, goal), 0, next(tie), start)]
    g_cost = {start: 0}
    parents = {start: None}
    expanded = 0
    while frontier:
        f, g, _, state = heapq.heappop(frontier)
        if g > g_cost[state]:
            continue
        expanded += 1
        if state == goal:
            return parents, g, expanded
        for move, nxt in neighbors(state):
            ng = g + 1
            if ng < g_cost.get(nxt, float("inf")):
                g_cost[nxt] = ng
                parents[nxt] = (state, move)
                heapq.heappush(frontier, (ng + manhattan(nxt, goal), ng, next(tie), nxt))
    return None, None, expanded

if __name__ == "__main__":
    assert is_solvable(START), "unsolvable start state"
    parents, cost, expanded = astar(START)
    print_solution(parents, GOAL, "A* (Manhattan distance)")
    print(f"\nOptimal cost: {cost}   Nodes expanded: {expanded}")
