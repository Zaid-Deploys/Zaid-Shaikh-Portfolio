import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    iris.data, iris.target, test_size=0.3, random_state=42, stratify=iris.target)

scores = {}
for k in range(1, 22, 2):
    pipe = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=k))
    scores[k] = cross_val_score(pipe, X_train, y_train, cv=5).mean()
    print(f"k={k:2d}  CV accuracy={scores[k]:.3f}")
best_k = max(scores, key=scores.get)
print("\nBest k:", best_k)

model = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=best_k))
model.fit(X_train, y_train)
pred = model.predict(X_test)

print(f"\nTest accuracy: {accuracy_score(y_test, pred):.3f}")
print("\nConfusion matrix:\n", confusion_matrix(y_test, pred))
print("\n", classification_report(y_test, pred, target_names=iris.target_names))

sample = [[5.1, 3.5, 1.4, 0.2]]
print("Prediction for", sample[0], "->", iris.target_names[model.predict(sample)[0]])
