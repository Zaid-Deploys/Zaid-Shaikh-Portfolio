from math import gcd

def successors(state, cap_a, cap_b):
    a, b = state
    yield "Fill A", (cap_a, b)
    yield "Fill B", (a, cap_b)
    yield "Empty A", (0, b)
    yield "Empty B", (a, 0)
    pour = min(a, cap_b - b)
    yield "Pour A -> B", (a - pour, b + pour)
    pour = min(b, cap_a - a)
    yield "Pour B -> A", (a + pour, b - pour)

def dfs(cap_a, cap_b, target):
    start = (0, 0)
    stack = [(start, [("Start", start)])]
    visited = {start}
    while stack:
        state, path = stack.pop()
        if target in state:
            return path

        for action, nxt in reversed(list(successors(state, cap_a, cap_b))):
            if nxt not in visited:
                visited.add(nxt)
                stack.append((nxt, path + [(action, nxt)]))
    return None

def solvable(cap_a, cap_b, target):
    return target <= max(cap_a, cap_b) and target % gcd(cap_a, cap_b) == 0

def show(cap_a, cap_b, target):
    print(f"\n=== Jugs {cap_a}L and {cap_b}L, target {target}L "
          f"(theory says solvable: {solvable(cap_a, cap_b, target)}) ===")
    path = dfs(cap_a, cap_b, target)
    if path is None:
        print("No solution found.")
        return
    for i, (action, st) in enumerate(path):
        print(f"{i:2d}. {action:12s} -> {st}")
    print(f"DFS solution length: {len(path) - 1} steps")

if __name__ == "__main__":
    show(4, 3, 2)
    show(5, 3, 4)
    show(7, 5, 3)
    show(6, 4, 3)
