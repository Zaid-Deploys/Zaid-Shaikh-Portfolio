import pandas as pd

def load():
    try:
        from sklearn.datasets import fetch_openml
        d = fetch_openml("adult", version=2, as_frame=True)
        df = d.frame.copy()
        return df, "class", "Adult Census Income (OpenML)", ["sex", "race"]
    except Exception as e:
        print(f"[OpenML unavailable ({type(e).__name__}); using Breast Cancer dataset]\n")
        from sklearn.datasets import load_breast_cancer
        d = load_breast_cancer(as_frame=True)
        df = d.frame.copy()
        df["target"] = df["target"].map({0: "malignant", 1: "benign"})
        df["size_group"] = pd.qcut(df["mean radius"], 2, labels=["small_tumor", "large_tumor"])
        return df, "target", "Breast Cancer Wisconsin (sklearn)", ["size_group"]

df, target, name, groups = load()
print(f"Dataset: {name}   rows={len(df)}   columns={df.shape[1]}")

dist = df[target].value_counts()
print("\nClass distribution:")
for cls, n in dist.items():
    print(f"  {cls:10s} {n:6d}  ({n / len(df):.1%})")
ratio = dist.max() / dist.min()
print(f"Imbalance ratio (majority:minority) = {ratio:.2f}:1")
print("Imbalance level:", "severe" if ratio > 9 else "moderate" if ratio > 3 else "mild/none")
print(f"A model that always predicts '{dist.idxmax()}' scores {dist.max() / len(df):.1%} accuracy")

for g in groups:
    print(f"\nRepresentation by '{g}':")
    print((df[g].value_counts(normalize=True) * 100).round(1).to_string())
    print(f"\nClass distribution within each '{g}' group (row %):")
    print((pd.crosstab(df[g], df[target], normalize="index") * 100).round(1).to_string())

print("\nObservations:")
print(f"- Majority class makes up {dist.max() / len(df):.1%} of the data, so accuracy alone is misleading;")
print("  use precision/recall/F1 per class, balanced accuracy or ROC-AUC.")
print("- If group representation or per-group class rates differ a lot, a model can learn the")
print("  group as a proxy for the label (sampling/historical bias).")
print("- Mitigations: stratified splits, class weights, over/under-sampling (SMOTE), per-group metrics.")
