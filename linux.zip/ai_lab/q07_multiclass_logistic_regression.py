import numpy as np
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

wine = load_wine()
X_train, X_test, y_train, y_test = train_test_split(
    wine.data, wine.target, test_size=0.25, random_state=42, stratify=wine.target)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
model.fit(X_train, y_train)
pred = model.predict(X_test)
proba = model.predict_proba(X_test)

print(f"Train accuracy: {model.score(X_train, y_train):.3f}")
print(f"Test accuracy : {accuracy_score(y_test, pred):.3f}")
print("\nConfusion matrix (rows=true, cols=predicted):\n", confusion_matrix(y_test, pred))
print("\n", classification_report(y_test, pred, target_names=wine.target_names))

print("Sample predictions (class probabilities):")
for i in range(5):
    print(f"  true={wine.target_names[y_test[i]]:8s} pred={wine.target_names[pred[i]]:8s} "
          f"P={np.round(proba[i], 3)}")

coef = model[-1].coef_
print("\nTop 3 influential features per class:")
for c, name in enumerate(wine.target_names):
    top = np.argsort(-np.abs(coef[c]))[:3]
    print(f"  {name}: {[wine.feature_names[j] for j in top]}")
