import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.tree import DecisionTreeRegressor, export_text
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

data = load_diabetes()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42)

def report(name, model):
    p_tr, p_te = model.predict(X_train), model.predict(X_test)
    print(f"{name:28s} train R2={r2_score(y_train, p_tr):.3f} | "
          f"test R2={r2_score(y_test, p_te):.3f}  "
          f"RMSE={np.sqrt(mean_squared_error(y_test, p_te)):.2f}  "
          f"MAE={mean_absolute_error(y_test, p_te):.2f}")

full = DecisionTreeRegressor(random_state=42).fit(X_train, y_train)
report("Unrestricted tree", full)

grid = GridSearchCV(
    DecisionTreeRegressor(random_state=42),
    {"max_depth": [2, 3, 4, 5, 6, 8], "min_samples_leaf": [1, 5, 10, 20]},
    cv=5, scoring="r2").fit(X_train, y_train)
best = grid.best_estimator_
print("Best params:", grid.best_params_)
report("Tuned tree", best)

print("\nFeature importances (tuned tree):")
for n, imp in sorted(zip(data.feature_names, best.feature_importances_),
                     key=lambda t: -t[1]):
    print(f"  {n:4s} {imp:.3f}")

print("\nSample predictions vs actual:")
for pred, actual in list(zip(best.predict(X_test), y_test))[:8]:
    print(f"  predicted {pred:7.1f}   actual {actual:6.1f}")

print("\nTree rules (depth<=2 view):")
print(export_text(best, feature_names=list(data.feature_names), max_depth=2))
