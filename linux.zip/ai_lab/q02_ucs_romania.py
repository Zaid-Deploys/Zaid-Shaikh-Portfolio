import heapq

GRAPH = {
    "Arad": {"Zerind": 75, "Sibiu": 140, "Timisoara": 118},
    "Zerind": {"Arad": 75, "Oradea": 71},
    "Oradea": {"Zerind": 71, "Sibiu": 151},
    "Sibiu": {"Arad": 140, "Oradea": 151, "Fagaras": 99, "Rimnicu Vilcea": 80},
    "Timisoara": {"Arad": 118, "Lugoj": 111},
    "Lugoj": {"Timisoara": 111, "Mehadia": 70},
    "Mehadia": {"Lugoj": 70, "Drobeta": 75},
    "Drobeta": {"Mehadia": 75, "Craiova": 120},
    "Craiova": {"Drobeta": 120, "Rimnicu Vilcea": 146, "Pitesti": 138},
    "Rimnicu Vilcea": {"Sibiu": 80, "Craiova": 146, "Pitesti": 97},
    "Fagaras": {"Sibiu": 99, "Bucharest": 211},
    "Pitesti": {"Rimnicu Vilcea": 97, "Craiova": 138, "Bucharest": 101},
    "Bucharest": {"Fagaras": 211, "Pitesti": 101, "Giurgiu": 90, "Urziceni": 85},
    "Giurgiu": {"Bucharest": 90},
    "Urziceni": {"Bucharest": 85, "Hirsova": 98, "Vaslui": 142},
    "Hirsova": {"Urziceni": 98, "Eforie": 86},
    "Eforie": {"Hirsova": 86},
    "Vaslui": {"Urziceni": 142, "Iasi": 92},
    "Iasi": {"Vaslui": 92, "Neamt": 87},
    "Neamt": {"Iasi": 87},
}

def ucs(graph, start, goal):
    frontier = [(0, start, [start])]
    best = {start: 0}
    expanded = 0
    while frontier:
        cost, node, path = heapq.heappop(frontier)
        if cost > best.get(node, float("inf")):
            continue
        expanded += 1
        if node == goal:
            return cost, path, expanded
        for nbr, w in graph[node].items():
            new_cost = cost + w
            if new_cost < best.get(nbr, float("inf")):
                best[nbr] = new_cost
                heapq.heappush(frontier, (new_cost, nbr, path + [nbr]))
    return None, None, expanded

if __name__ == "__main__":
    cost, path, expanded = ucs(GRAPH, "Arad", "Bucharest")
    print("Least-cost path:", " -> ".join(path))
    print("Total cost     :", cost)
    print("Nodes expanded :", expanded)
