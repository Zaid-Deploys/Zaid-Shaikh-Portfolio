import numpy as np, pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (classification_report, confusion_matrix,
                             balanced_accuracy_score, recall_score, accuracy_score)

d = load_breast_cancer(as_frame=True)
df = d.frame.copy()
rng = np.random.RandomState(42)
mal = df[df.target == 0].sample(frac=0.17, random_state=42)
ben = df[df.target == 1]
df = pd.concat([mal, ben]).sample(frac=1, random_state=42).reset_index(drop=True)

names = {0: "malignant", 1: "benign"}
counts = df.target.value_counts()
print("Class distribution after down-sampling:")
for k, v in counts.items():
    print(f"  {names[k]:10s} {v:4d} ({v / len(df):.1%})")
print(f"Imbalance ratio {counts.max() / counts.min():.1f}:1\n")

df["size_group"] = pd.qcut(df["mean radius"], 2, labels=["small", "large"])
print("Malignant share by tumour-size group:")
print((pd.crosstab(df.size_group, df.target.map(names), normalize="index") * 100).round(1), "\n")

X, y = df[d.feature_names], df.target
X_tr, X_te, y_tr, y_te, g_tr, g_te = train_test_split(
    X, y, df.size_group, test_size=0.3, random_state=42, stratify=y)

def evaluate(title, **kw):
    clf = DecisionTreeClassifier(max_depth=4, random_state=42, **kw).fit(X_tr, y_tr)
    pred = clf.predict(X_te)
    print(f"--- {title} ---")
    print(f"Accuracy={accuracy_score(y_te, pred):.3f}  "
          f"Balanced accuracy={balanced_accuracy_score(y_te, pred):.3f}  "
          f"Malignant recall={recall_score(y_te, pred, pos_label=0):.3f}")
    print("Confusion matrix (rows=true [malignant, benign]):\n", confusion_matrix(y_te, pred))
    print(classification_report(y_te, pred, target_names=["malignant", "benign"], zero_division=0))
    print("Malignant recall by size group:")
    for g in ["small", "large"]:
        m = (g_te == g).values & (y_te == 0).values
        if m.sum():
            print(f"  {g:5s}: {(pred[m] == 0).mean():.2f}  (n_malignant={m.sum()})")
    print()

evaluate("Baseline tree (no balancing)")
evaluate("Tree with class_weight='balanced'", class_weight="balanced")

print("Observations:")
print("- Accuracy looks high even if minority recall is weak -> accuracy hides imbalance.")
print("- class_weight='balanced' usually lifts minority recall at a small cost in precision.")
print("- Compare per-group recall: large gaps indicate the model treats groups unequally.")
